<script>
    export let avatar = "";
    export let width = '100%';
    export let height = '100%';
</script>


<iframe src={avatar} frameborder='0' width={width} height={height} title="avatar"></iframe>





